import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:nhac/globals/router.dart';
import 'package:nhac/models/usuario/usuario_model.dart';
import 'package:nhac/repositories/user_repository.dart';
import 'package:nhac/services/auth_service.dart';

class UserProvider with ChangeNotifier {
  final AuthService _authService;
  final UserRepository _userRepository;

  UserProvider({AuthService? authService, UserRepository? repository})
      : _authService = authService ?? authServiceRoteador,
        _userRepository = repository ?? UserRepository();

  UsuarioModel? _usuario;
  bool _isLoading = false;

  UsuarioModel? get usuario => _usuario;
  bool get isLoading => _isLoading;

  // Login social (Google) e por telefone não são suportados pelo backend
  // atual — toda conta hoje é criada por e-mail + senha via /auth/registrar.
  // TODO(backend): reabilitar quando /auth/social existir.
  bool get isGoogleUser => false;
  bool get hasPassword => true;

  Future<void> carregarDadosUsuario() async {
    final usuarioId = _authService.usuarioId;
    if (usuarioId == null) return;

    try {
      _isLoading = true;
      notifyListeners();

      _usuario = await _userRepository.buscarUsuario(usuarioId);
    } catch (e) {
      debugPrint("Erro ao carregar dados do utilizador: $e");
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> atualizarFotoPerfil(File imagem) async {
    final usuarioId = _authService.usuarioId;

    if (usuarioId == null) {
      throw Exception("Utilizador não autenticado no Provider.");
    }

    try {
      _isLoading = true;
      notifyListeners();

      final storage = FirebaseStorage.instanceFor(app: Firebase.app());

      // Ver comentário equivalente em editar_foto_page.dart: o Storage
      // exige request.auth != null, mas o app não usa mais Firebase Auth
      // para login. Login anônimo satisfaz a regra sem exigir conta.
      if (FirebaseAuth.instance.currentUser == null) {
        await FirebaseAuth.instance.signInAnonymously();
      }
      final ref = storage.ref().child('usuarios').child(usuarioId).child('perfil.jpg');

      await ref.putFile(
        imagem,
        SettableMetadata(contentType: 'image/jpeg'),
      );

      final url = await ref.getDownloadURL();

      await _userRepository.atualizarDadosUsuario(usuarioId, {
        'imagemUrl': url,
      });

      await carregarDadosUsuario();
    } catch (e) {
      debugPrint("Erro ao atualizar foto de perfil: $e");
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void limparUsuario() {
    _usuario = null;
    notifyListeners();
  }
}
